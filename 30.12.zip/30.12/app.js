let express = require('express');
let fs = require("fs");
let app = express();
let urlencodedParser = express.urlencoded({extended: false});

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/html/student.html");
})

app.get("/students", (req, res) => {
    res.sendFile(__dirname + "/db.txt");
});

app.post("/students", urlencodedParser, (req, res) => {
    let studentsArray = JSON.parse(fs.readFileSync("db.txt", "utf8"));

    let studentData = {
        firstname: req.body.firstname,
        group: req.body.group
    }

    studentsArray.push(studentData);

    fs.writeFileSync("db.txt", JSON.stringify(studentsArray));

    res.send("OK!");
});

app.listen(8080);